package com.example.demo.model.jsonRequest;

public class Message {


}

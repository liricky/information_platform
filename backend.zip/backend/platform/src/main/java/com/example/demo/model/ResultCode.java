package com.example.demo.model;

//返回状态枚举型
public enum ResultCode {
    SUCCESS,
    FAILED
}

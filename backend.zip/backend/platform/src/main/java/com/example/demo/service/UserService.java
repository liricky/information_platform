package com.example.demo.service;

import com.example.demo.model.ov.Result;

public interface UserService {

    Result usergetfriend(String userid);

}
